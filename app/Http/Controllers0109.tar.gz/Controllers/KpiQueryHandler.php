<?php
/**
 * Created by PhpStorm.
 * User: yang
 * Date: 2018/11/27
 * Time: 18:02
 */

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Http\Controllers\Common\DataBaseConnection;
use Illuminate\Support\Facades\Redis;
use PDO;
use Exception;
trait KpiQueryHandler
{
    use FormulaHandler;
    //数据库类型：ENIQ
    public $dataSource;
    //数据类型：TDD/FDD/NBIOT/GSM
    public $dataType;
    //模版名
    public $template;
    //时间类型：天/day,天组/dayGroup,小时/hour,小时组/hourgroup,15分钟/quarter
    public $timeDim;
    //查询维度：city/城市,subnet/子网,subnetGroup/子网组,baseStation/基站,baseStationGroup/基站组,cell/小区,cellGroup/小区组
    public $locationDim;
    //城市
    public $cities;
    //子网
    public $subnets;
    //基站
    public $baseStation;
    //小区
    public $cell;
    //日期
    public $dateStart;
    public $dateEnd;
    //小时
    public $hour;
    public $minute;

    public $resultText;
    public $sql;

    public $localDB;//模版所在数据库

    public $neighborCell;//邻区对

    public function __construct(){
        $this->sql = new \stdClass();
    }
    public function query(Request $request)
    {   

        $this->dataSource = "ENIQ";
        $this->dataType = $request['dataType'];
        $this->template = $request['template'];
       
        $subnets = array("changzhou:CZ_Wujin_g1tdd1","nantong:Nantong1_LTE","nantong:Nantong2_LTE","nantong:Nantong4_LTE","nantong:Nantong3_LTE","nantong:Nantong_wlan","nantong2:NT_Nantong_G2tdd1","wuxi:WX_yixing_g2tdd");
        $subnets = $request['subnets'];
        foreach ($subnets as $key => $value) {
            if($value&&$value!=="allSelect"){
                $city = explode(":",$value);
                $newsubnets[$city[0]][]=$city[1];
            }
        }
        // print_r($newsubnets);
        // print_r(array_keys($newsubnets));
        // print_r(array_values($newsubnets));
        $this->cities = array_keys($newsubnets);
        $this->subnets =$newsubnets;
        $this->timeDim = $request['timeDim'];
        $this->locationDim = $request['locationDim'];
        $this->baseStation = $request['baseStation'];
        $this->cell = $request['cell'];
        $this->dateStart =substr($request['date'][0],0,10);
        $this->dateEnd =substr($request['date'][1],0,10);
        $this->hour = $request['hour'];
        $this->minute = $request['minute'];
        $this->result="";

        $dbc = new DataBaseConnection();
        $this->localDB = $dbc->getDB("mongs");

        $sql = "select description from template where templateName='".$this->template."' limit 1";

        $result = $this->localDB->query($sql)->fetchAll(PDO::FETCH_ASSOC);

        if($result[0]['description']=="neighborCell"){
            $this->neighborCell = true;
        }else{
            $this->neighborCell=false;
        }

        // Step1
        // getKpis;
        // Step2
        // createSQL
        // // Step A) createslectSql()
        // // Step B) 
        // exit;
    }

    // Create query sql
    public function createSql($city,$subnetwork)
    {   
        $subnetwork = $this->getSubnetWork($city);//获取子网

        if($this->timeDim=="day"){
            $this->sql->selectSql = "select AGG_TABLE0.DAY,AGG_TABLE0.location,AGG_TABLE0.cellNum,";
            $this->sql->resultText ="day,location,cellNum";
            $this->sql->orderbySql = " ORDER BY AGG_TABLE0.DAY";
        }elseif($this->timeDim=="dayGroup"){
            $this->sql->selectSql = "select AGG_TABLE0.DAY,AGG_TABLE0.location,AGG_TABLE0.cellNum,";
            $this->sql->resultText ="dayGroup,location,cellNum";

            $this->sql->orderbySql = " ORDER BY AGG_TABLE0.DAY";
        }elseif($this->timeDim=="hour"){
            $this->sql->selectSql = "select AGG_TABLE0.DAY,AGG_TABLE0.HOUR,AGG_TABLE0.location,AGG_TABLE0.cellNum,";
            $this->sql->resultText ="day,hour,location,cellNum";

            $this->sql->orderbySql = " ORDER BY AGG_TABLE0.DAY,AGG_TABLE0.HOUR";
        }elseif($this->timeDim=="hourGroup"){
            $this->sql->selectSql = "select AGG_TABLE0.DAY,AGG_TABLE0.HOUR,AGG_TABLE0.location,AGG_TABLE0.cellNum,";
            $this->sql->resultText ="day,hourGroup,location,cellNum";

            $this->sql->orderbySql = " ORDER BY AGG_TABLE0.DAY,AGG_TABLE0.HOUR";

        }elseif($this->timeDim=="quarter"){
            $this->sql->selectSql = "select AGG_TABLE0.DAY,AGG_TABLE0.HOUR,AGG_TABLE0.MINUTE,AGG_TABLE0.location,AGG_TABLE0.cellNum,";
            $this->sql->resultText ="day,hour,minute,location,cellNum";

            $this->sql->orderbySql = " ORDER BY AGG_TABLE0.DAY,AGG_TABLE0.HOUR,AGG_TABLE0.MINUTE";

        }
        if($this->locationDim=="baseStation"){
            $this->sql->selectSql.="AGG_TABLE0.subNet,";
            $this->sql->resultText = str_replace("cellNum", "cellNum,subNet",  $this->sql->resultText);

        }
        if($this->locationDim=="cell"){
            $this->sql->selectSql.="AGG_TABLE0.subNet,AGG_TABLE0.site,";
            $this->sql->resultText = str_replace("cellNum", "cellNum,subNet,site",  $this->sql->resultText);

        }


            // subnet/子网,subnetGroup/子网组,baseStation/基站,baseStationGroup/基站组,cell/小区,cellGroup/小区组
            // if($this->locationDim=="subnet"){
            //       // $this->sql->selectSql = "select AGG_TABLE0.DAY,AGG_TABLE0.cellNum,AGG_TABLE0.location,AGG_TABLE0.location,";
            //     $this->sql->orderbySql = " ORDER BY AGG_TABLE0.DAY";
            // }elseif($this->locationDim=="subnetGroup"){

            // }elseif($this->locationDim=="baseStation"){
                
            // }elseif($this->locationDim=="baseStationGroup"){
                
            // }elseif($this->locationDim=="cell"){
                
            // }elseif($this->locationDim=="cellGroup"){
                
            // }

            $dbc = new DataBaseConnection();
            $localDB = $dbc->getDB("mongs");
            $kpis=$this->getKpis($localDB);
            $nosum_map = array();//max,min,avg
            $counterMap = $this->getCheckCounters($kpis['ids'],$localDB,$nosum_map);
            // print_r($nosum_map);
            // print_r($counterMap);
            // exit;
            $tables  = array_keys(array_count_values($counterMap));
            $aggselectSQL=$this->createSelectSql($city);
            $filterSQL=$this->createFilterSql($city);
            $groupbySQL=$this->createGroupBySql();
            if (count($tables) == 1) {
                $table = $tables[0];
                if (trim(substr($table, 0, (strlen($table) - 4))) == strtolower("DC_E_ERBS_EUTRANCELLRELATION") && $this->template != '切换成功率(不含邻区对)') {
                    if ($this->neighborCell){
                        $this->sql->selectSql.="AGG_TABLE0.relation,AGG_TABLE0.eufdd,";
                        $aggselectSQL    = $aggselectSQL."EUtranCellRelation as relation,EUtranCell".$this->dataType." as eufdd,";
                        $groupbySQL  = $groupbySQL.",eufdd,relation";
                        $this->sql->resultText.=",EUtranCellRelation,EUtranCell".$this->dataType;
                    }
                } else if (trim(substr($table, 0, (strlen($table) - 4))) == strtolower("DC_E_ERBS_GERANCELLRELATION") && $this->template != '2G邻区切换统计-不含GeranCellRelation') {
                    if ($this->neighborCell) {
                        $this->sql->selectSql.="AGG_TABLE0.relation,AGG_TABLE0.eufdd,";
                        $aggselectSQL    = $aggselectSQL."GeranCellRelation as relation,EUtranCell".$this->dataType." as eufdd,";
                        $groupbySQL  = $groupbySQL.",eufdd,relation";
                         $this->sql->resultText.=",GeranCellRelation,EUtranCell".$this->dataType;
                    }
                }
            }
            $this->sql->resultText .=','.$kpis['names']; 
            
             $counters = array_unique(array_keys($counterMap));

            foreach ($counters as $key => $value) {
                $this->sql->selectSql.=strtolower($value).",";
            }
            $this->sql->selectSql = trim($this->sql->selectSql,",")." from ";
            $tempTableSQL = "";
            $index        = 0;
            foreach ($tables as $table) {
                $countersForQuery = array_keys($counterMap, $table);
                $tableSQL         = $this->createSubQuerySql($countersForQuery,$aggselectSQL,$filterSQL,$groupbySQL,$table,$nosum_map);
                // print_r($tableSQL);exit;
                $tableSQL         = $tableSQL."as AGG_TABLE$index ";
                if ($index == 0) {
                    if ($index != (sizeof($tables) - 1)) {
                        $tableSQL = $tableSQL." left join";
                    }
                } else {
                    if ($this->timeDim == "dayGroup") {
                        $tableSQL = $tableSQL."on AGG_TABLE0.DAY = AGG_TABLE$index.DAY";
                    } else if ($this->timeDim == "day" || $this->timeDim == 'dayGroup') {
                        $tableSQL = $tableSQL."on AGG_TABLE0.day = AGG_TABLE$index.day";
                    } else if ($this->timeDim == "hour") {
                        $tableSQL = $tableSQL."on AGG_TABLE0.day = AGG_TABLE$index.day and AGG_TABLE0.hour = AGG_TABLE$index.hour";
                    } else if ($this->timeDim == "hourGroup") {
                        $tableSQL = $tableSQL."on AGG_TABLE0.day = AGG_TABLE$index.day and AGG_TABLE0.hour = AGG_TABLE$index.hour";
                    } else if ($this->timeDim == "quarter") {
                        $tableSQL = $tableSQL."on AGG_TABLE0.day = AGG_TABLE$index.day and AGG_TABLE0.hour = AGG_TABLE$index.hour and AGG_TABLE0.minute = AGG_TABLE$index.minute";
                    }
                    if ( $this->timeDim == "dayGroup" && $this->locationDim == 'cell' ) {
                        $tableSQL = $tableSQL." and AGG_TABLE0.location = AGG_TABLE$index.location";
                    }
                    // echo $locationDim;
                    if ($this->locationDim == "cellGroup" || $this->locationDim == "erbsGroup") {
                        // echo $locationDim;
                        $tableSQL = $tableSQL;
                    } else {
                        // echo $tableSQL;
                        $tableSQL = $tableSQL." and AGG_TABLE0.location = AGG_TABLE$index.location";
                    }

                    if ($index != (sizeof($tables) - 1)) {
                        $tableSQL = $tableSQL." left join ";
                    }
                }//end if
                $tempTableSQL = $tempTableSQL.$tableSQL;
                $index++;
            }//end foreach

        
        $sql =    $this->sql->selectSql.$tempTableSQL.$this->sql->orderbySql;
        return $sql;


    }

    // Create select sql
    public function createSelectSql($city)
    {      
        $subnetwork = $this->getSubnetWork($city);//获取子网
        $SN = $this->getSN($this->dataType,$city);
        $conname = trim(preg_replace('/[0-9]+/', '', $city));
    
        $left = "select ";
        $middle = "";
        $right = "";
        if($this->dataSource=="ENIQ"){
            if($this->timeDim=="day"){
                $left.="convert(char(10),date_id) as day,";
                // $selectSql.="convert(char(10),date_id) as day,'$conname' as location,";
            }elseif($this->timeDim=="dayGroup"){
                $left.="'ALLDAY' as day,";

                // $selectSql.="'ALLDAY' as day,'$conname' as location,";
            }elseif($this->timeDim=="hour"){
                $left.="convert(char(10),date_id) as day,";
                $right.="hour_id as hour,";
                // $selectSql .= "convert(char(10),date_id) as day,'$conname' as location,hour_id as hour,";
            }elseif($this->timeDim=="hourGroup"){
            
                if (!$this->hour) {
                    $hour = 'AllHour';
                } else {
  
                    $hour = implode(',',$this->hour);
                }
                $left.="convert(char(10),date_id) as day,";
                $right.="'$hour' as hour,";

                // $selectSql .= "convert(char(10),date_id) as day,'$conname' as location,'$hour' as hour,";
            }elseif($this->timeDim=="quarter"){
                $left.="convert(char(10),date_id) as day,";
                $right.="hour_id as hour,min_id as minute,";
                // $selectSql .= "convert(char(10),date_id) as day,'$conname' as location,hour_id as hour,min_id as minute,";
            }
        //查询维度：city/城市,subnet/子网,subnetGroup/子网组,baseStation/基站,baseStationGroup/基站组,cell/小区,cellGroup/小区组
            if($this->locationDim=="city"){
                $middle.="'$conname' as location,";
            }elseif($this->locationDim=="subnet"){
                $middle .="$subnetwork as location,";
            }elseif($this->locationDim=="subnetGroup"){
                $middle .="'subnetworkGroup' as location,";

            }elseif($this->locationDim=="baseStation"){
                $middle .="$subnetwork as subNet,erbs AS location,";
                
            }elseif($this->locationDim=="baseStationGroup"){
                $middle .="'AllErbs' AS location,";
                
            }elseif($this->locationDim=="cell"){
                 //数据类型：TDD/FDD/NBIOT/GSM
            // public $dataType;
                $middle .="$subnetwork as subNet,$SN,";
                if($this->dataType=="TDD"){
                    $middle.="EutranCellTDD as location,";
                }elseif($this->dataType=="FDD"){
                    $middle.="EutranCellFDD as location,";

                }elseif($this->dataType=="NBIOT"){
                    $middle.="NbIotCell as location,";
                }
            }elseif($this->locationDim=="cellGroup"){
                $middle .="'cellGroup' AS location,";
            }

        }
        return $left.$middle.$right;
    }


    // Create filter sql
    public function createFilterSql($city)
    {   
        //获取单个地市的子网 array()
        $subNetwork = $this->subnets[$city];
        $substr = "";
        foreach ($subNetwork as $key => $value) {
            $substr .="'".$value."',";
        }
        $substr = trim($substr,",");//子网string


        if($this->dataSource=="ENIQ"){

            $subnetwork = $this->getSubnetWork($city);//获取子网
            $aggWhereSql = " where date_id>='".$this->dateStart."' and date_id<='".$this->dateEnd."' and $subnetwork in ($substr)";

            if($this->timeDim=="day"){
            }elseif($this->timeDim=="dayGroup"){
            }elseif($this->timeDim=="hour"){
                if($this->hour){
                    $hour = implode(",", $this->hour);
                    $aggWhereSql.="and hour_id in($hour)";
                }
            }elseif($this->timeDim=="hourGroup"){
                 if($this->hour){
                    $hour = implode(",", $this->hour);
                    $aggWhereSql.="and hour_id in($hour)";
                }
            }elseif($this->timeDim=="quarter"){
                 if($this->hour){
                    $hour = implode(",", $this->hour);
                    $aggWhereSql.="and hour_id in($hour)";
                } 
                if($this->minute){
                    $hour = implode(",", $this->minute);
                    $aggWhereSql.="and min_id in($hour)";
                }else{
                    $aggWhereSql.="and min_id in(0,15,30,45)";

                }
            }
            if($this->locationDim=="baseStation"||$this->locationDim=="baseStationGroup"){
                if($this->baseStation){
                    $baseStation = trim($this->baseStation);
                    $baseStation="'".str_replace(",", "','", $baseStation)."'";
                    $aggWhereSql.="and erbs in($baseStation)";
                }
            }
              if($this->locationDim=="cell"||$this->locationDim=="cellGroup"){
                if($this->cell){
                    $cell = trim($this->cell);
                    $cell="'".str_replace(",", "','", $cell)."'";
                    if($this->dataType=="TDD"){
                     $aggWhereSql.="and EutranCellTDD in($cell)";

                    }elseif($this->dataType=="FDD"){
                        $aggWhereSql.="and EutranCellFDD in($cell)";

                    }elseif($this->dataType=="NBIOT"){
                        $aggWhereSql.="and NbIotCell in($cell)";
                    }
                }
            }


        }
        return $aggWhereSql;
    }

    // Create group by sql
    public function createGroupBySql()
    {   $aggGroupBy = "";
        if($this->dataSource=="ENIQ"){
            if($this->timeDim=="day"){
                $aggGroupBy = " group by DAY,location";
            }elseif($this->timeDim=="dayGroup"){
                $aggGroupBy = " group by DAY,location";
            }elseif($this->timeDim=="hour"){
                $aggGroupBy = " group by DAY,hour_id,location";
            }elseif($this->timeDim=="hourGroup"){
                $aggGroupBy = " group by DAY,hour,location";
            }elseif($this->timeDim=="quarter"){
                $aggGroupBy = " group by DAY,hour_id,min_id,location";
            }
            if($this->locationDim=="baseStation"||$this->locationDim=="cell"){
                $aggGroupBy.=",SN";
            }


        }
        return $aggGroupBy;
      
    }

    // Create sub query sql for each table
    public function createSubQuerySql($countersForQuery,$selectSQL,$filterSQL,$groupbySQL,$table,$nosum_map)
    {   
        $aggTypes = $this->loadAggTypes();
        $pattern_nosum = "/(max|min|avg)\((.*)\)/";
        $i=0;
        if($this->dataType=="TDD"){
            $selectSQL.="count(distinct(EutranCellTDD)) as cellNum,";
        }elseif($this->dataType=="FDD"){
            $selectSQL.="count(distinct(EutranCellFDD)) as cellNum,";

        }elseif($this->dataType=="NBIOT"){
            $selectSQL.="count(distinct(NbIotCell)) as cellNum,";

        }

        // print_r($countersForQuery);
        // print_r($table);
        // print_r($city);
        // exit;
        // if (!$local_flag) {
        //     if ($this->format == 'TDD') {
        //         if ($flag == 'false') {
        //             $selectSQL .= "COUNT(DISTINCT(ERBS)) AS cellNum,";
        //             $resultText = str_replace('cellNum', 'erbsNum', $resultText);
        //         } else {
        //             if ($flag1 == 'false') {
        //                 $selectSQL .= "COUNT(DISTINCT(ERBS)) AS cellNum,";
        //                 $resultText = str_replace('cellNum', 'erbsNum', $resultText);
        //             } else {
        //                 $selectSQL .= "COUNT(DISTINCT(EutranCellTDD)) AS cellNum,";
        //             }
        //         }
        //     } else if ($format == 'FDD') {
        //         $selectSQL .= "COUNT(DISTINCT(ERBS)) AS cellNum,";
        //         $resultText = str_replace('cellNum', 'erbsNum', $resultText);
        //     }else if($format=="NBIOT"){
        //         $selectSQL .= "COUNT(DISTINCT(NbIotCell)) AS cellNum,";
        //         $resultText = str_replace('erbsNum', 'cellNum', $resultText);
        //     }
        // }
        foreach ($countersForQuery as $counter) {
            $counter     = trim($counter);
            $counterName = $counter;

         if (stripos($counter, "_") !== false) {
                $elements = explode("_", $counter);
                $name     = $elements[0];
                $index    = $elements[1];
                $counter  = $this->convertInternalCounter($name, $index);
                $selectSQL .=$counter." as '$counterName',";
            } else {
                if(array_key_exists($counter, $nosum_map)){
                // echo $nosum_map[$counter];
                    $selectSQL = $selectSQL.$nosum_map[$counter]." as '$counterName',";
                }else{
                    $aggType = $this->getAggType($aggTypes, $counter);
                    $counter = "$aggType($counter)";
                    $selectSQL = $selectSQL.$counter." as '$counterName',";
                }
             
                // print_r($aggType);exit;
            }
            // print_r($selectSQL);exit;
            // $selectSQL = $selectSQL.$counter." as '$counterName',";
        }
        $selectSQL = substr($selectSQL, 0, (strlen($selectSQL) - 1));
        // $selectSQL = "($selectSQL from dc.$table ". $this->createFilterSql($city).$this->createGroupBySql().")";
            return "($selectSQL from dc.$table $filterSQL $groupbySQL)";
    }

    // Create subNetwork sql
    public function createSubNetSql()
    {
       

    }

    // Export query result
    public function download($data,$title)
    {   
        $fileName="common/files/".trim($this->template)."_".date("YmdHis").".csv";
        $csvContent = mb_convert_encoding($title."\n", 'GBK');
        $fp         = fopen($fileName, "w");
        fwrite($fp, $csvContent);
        foreach ($data as $row) {
            $newRow = array();
            foreach ($row as $key => $value) {
                $newRow[$key] = mb_convert_encoding($value, 'GBK');
            }

            fputcsv($fp, $newRow);
        }

        fclose($fp);
        return $fileName;
    }

    /**
     * [getKpis description]
     * @DateTime 2018-12-12
     * @param    [type]     $localDB [description]
     * @return   [type]              [description]
     */
    public function getKpis($localDB)
    {

        // $queryKpiset  = "select elementId from template where templateName='".$this->template."' and user = '$parent'";
        $queryKpiset  = "select elementId from template where templateName='".$this->template."'";
        $res          = $localDB->query($queryKpiset);
        $kpis         = $res->fetchColumn();
        $kpisStr      = ','.$kpis.',';
        $queryKpiName = "select kpiName,kpiPrecision,kpiFormula,instr('$kpisStr',CONCAT(',',id,',')) as sort from kpiformula where id in ($kpis) order by sort";
        $res          = $localDB->query($queryKpiName)->fetchAll(PDO::FETCH_ASSOC);
        $kpiNames     = "";
        $result          = array();
        foreach ($res as $row) {
            $result['kpiformula'][] = $row;
            $kpiNames = $kpiNames.trim($row['kpiName']).",";
        }

        $kpiNames        = substr($kpiNames, 0, (strlen($kpiNames) - 1));
        $result['ids']   = $kpis;
        $result['names'] = $kpiNames;
        return $result;
    }


    protected function getCheckCounters($queryFormula, $localDB,&$nosum_map) {
        if($this->dataType=="TDD"){
            $counters = unserialize(Redis::get("Counters_TDD"));

        }elseif($this->dataType=="FDD"){
            $counters = unserialize(Redis::get("Counters_FDD"));
            
        }elseif($this->dataType=="NBIOT"){
            $counters = unserialize(Redis::get("Counters_NBIOT"));

        }
        $queryFormula  = "select kpiName,kpiFormula,kpiPrecision,instr('$queryFormula,',CONCAT(id,',')) as sort from kpiformula where id in (".$queryFormula.") order by sort";
        $check = [];
        $counterMap = array();
        foreach ($localDB->query($queryFormula) as $row) {
            $kpi = $row['kpiFormula'];
            $pattern       = "/[\(\)\+\*-\/]/";
            $columns       = preg_split($pattern, $kpi);
            $matches       = array();
            $pattern_nosum = "/(max|min|avg)\((.*)\)/";
            foreach ($columns as $column) {
                $column      = trim($column);
                $counterName = $column;
                if (stripos($counterName, "pm") === false) {
                    continue;
                }

                if (stripos($counterName, "_") !== false) {
                    $elements    = explode("_", $counterName);
                    $counterName = $elements[0];
                }
                if (array_key_exists(strtolower($counterName), $counters)) {
                    $table = $counters[strtolower($counterName)];
                } else {
                    continue;
                }

                if($this->dataType=="NBIOT"){
                    $table = trim($table)."_RAW";
                }else{
                    if($this->timeDim=="hour"||$this->timeDim=="quarter"){
                        $table=trim($table)."_RAW";
                    }else{
                        $table   = ($this->timeDim == "day") ? trim($table)."_DAY" : trim($table)."_RAW";
                    }
                }

                if (preg_match($pattern_nosum, $kpi, $matches)) {
                    $counterMap[strtolower($matches[2])] = strtolower($table);
                    
                    $nosum_map[strtolower($matches[2])]=strtolower($kpi);
                    break;
                }

                if (!array_key_exists($column, $counterMap)) {
                    $counterMap[strtolower($column)] = strtolower($table);
                }
            }//end foreach
        }
        
        return $counterMap;
    }
        /**
     * 转换内部计数器
     *
     * @param string $counterName 计数器名
     * @param string $index       向量值
     *
     * @return mixed
     */
    protected function convertInternalCounter_minmaxavg($minmaxavg, $counterName, $index)
    {
        $SQL = $minmaxavg."(case DCVECTOR_INDEX when $index then $counterName else 0 end)";
        return str_replace("\n", "", $SQL);

    }//end convertInternalCounter()


    /**
     * 获得聚合类型
     *
     * @param array  $aggTypes    聚合类型集合
     * @param string $counterName 计数器名
     *
     * @return string
     */
    protected function getAggType($aggTypes, $counterName)
    {
        // print_r($aggTypes);print_r($counterName);exit;
        if (!array_key_exists($counterName, $aggTypes)) {
            return "sum";
        }

        return trim($aggTypes[$counterName]);

    }//end getAggType()
        protected function convertInternalCounter($counterName, $index)
    {
        $SQL = "sum(case DCVECTOR_INDEX when $index then $counterName else 0 end)";
        return str_replace("\n", "", $SQL);

    }//end convertInternalCounter()

    public function getSubnetWork($oss) {
        $SN = "";
        switch ($oss) {
            case 'wuxiENM':
                $SN = "substring(substring(SN, 0, charindex(',',SN)-1), 12)";
                break;
            case "wuxi1":
                $SN = "substring(SN, 12, charindex(',', SN)-12)";
                break;
          case "wuxi2":
            $SN = "substring(SN, 12, charindex(',', SN)-12)";
            break;
          case "wuxi":
            $SN = "substring(SN, 12, charindex(',', SN)-12)";
            break;
            case "suzhou3":
                $SN = "substring(SN, 12, charindex(',', SN)-12)";
                break;
            case "zhenjiang":
                $SN = "substring(substring(SN, 0, charindex(',',SN)-1), 12)";
            break;
            case "zhenjiang1":
                $SN = "substring(substring(SN, charindex(',', SN)+12), 0, charindex(',', substring(SN, charindex(',', SN)+12))-1)";
                break;
            case "changzhou":
              $SN = "substring(SN, charindex('=', SN)+1, charindex(',', SN)-charindex('=', SN)-1)";
              break;
            case "suzhou":
              $SN = "substring(SN, charindex('=', SN)+1, charindex(',', SN)-charindex('=', SN)-1)";
              break;
            case "nantong":
              $SN = "substring(SN, charindex('=', SN)+1, charindex(',', SN)-charindex('=', SN)-1)";
              break;
            default:
                $SN = "substring(SN,charindex('=',substring(SN,32,25))+32,charindex(',',substring(SN,32,25))-charindex('=',substring(SN,32,25))-1)";
                break;
        }
        return $SN;
    }

    public function getSN($format, $oss) {
        $SN = "";
        switch ($format) {
            case 'NBIOT':
                switch ($oss) {
                    case 'wuxiENM':
                        $SN = "SN  as site";
                        break;
                    case "suzhou3":
                        $SN = "SN  as site";
                        break;
            case "changzhou":
              $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
              break;
            case "nantong":
              $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
              break;
                    default:
                        $SN = "substring(substring(SN,charindex (',', substring(SN, 32, 25)) + 32),11,25) as site";
                        break;
                }
                break;
            default:
                switch ($oss) {
                    case 'wuxiENM':
                        $SN = "SN  as site";
                        break;
                    case "zhenjiang1":
                        $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                        break;
                    case "zhenjiang":
                        $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                        break;
                    case "suzhou3":
                        $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                        break;
                    case "wuxi1":
                        $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                        break;
                    case "wuxi":
                        $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                        break;
                case "wuxi2":
                    $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                    break;
                    case "changzhou":
                        $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                        break;
                case "suzhou":
                    $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                    break;
                case "nantong":
                    $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                    break;
                    default:
                        $SN = "substring(substring(SN,charindex (',', substring(SN, 32, 25)) + 32),11,25) as site";
                        break;
                }
                break;
        }
        return $SN;
    }
        /**
     * 获得AVG聚合类型的计数器集合
     *
     * @return array
     */
    public function loadAggTypes()
    {
        $aggTypeDefs = file("txt/AggTypeDefine.txt");
        $aggTypes    = array();

        foreach ($aggTypeDefs as $aggTypeDef) {
            $aggType = explode("=", $aggTypeDef);
            $aggTypes[$aggType[0]] = $aggType[1];
        }

        return $aggTypes;

    }//end loadAggTypes()


    public function getResult($result){
        $kpis=$this->getKpis($this->localDB);
        $nosum_map = array();
        $counterMap = $this->getCheckCounters($kpis['ids'],$this->localDB,$nosum_map);
        $counters = array_values(array_unique(array_keys($counterMap)));//获取所有的pm键值
        $data = array();
        foreach ($result as $key => $value) {

                if(count($value)>1){
                    $newArray = [];
                    if($this->locationDim=="city"){
                        $newArray = $this->mergeOssData($value,$counters,$nosum_map);
                    }elseif($this->locationDim=="subnetGroup"){
                        $newArray = $this->mergeOssData($value,$counters,$nosum_map);
                    }elseif($this->locationDim=="baseStationGroup"){
                        $newArray = $this->mergeOssData($value,$counters,$nosum_map);
                    }else{
                        foreach ($value as $k => $v) {
                            $newArray = array_merge($newArray,$v);
                        }
                    }
                }else{
                    $newArray = $value[0];
                }

                 $result = $this->getResultArray(array($newArray),$kpis);
                 $data = array_merge($data,$result);
                    
        }
        
               return $data;

    }
    /**
     * 合并多个OSS的情况数据
     * @DateTime 2018-12-26
     * @return   array();
     */
    public function mergeOssData($data,$counters,$nosum_map){
        $len = count($data);
        array_push($counters, "cellNum");

        for($i=0;$i<$len;$i++){
            foreach ($data[$i] as $value) {
                $key = $value['DAY'].$value['location'];
                if(array_key_exists("HOUR", $value)){
                    $key.=$value['HOUR'];
                }
                if(array_key_exists("MINUTE", $value)){
                    $key.=$value['MINUTE'];
                }

                $newData[$key][]=$value;

            }
        }

        foreach ($newData as $key => $value) {
            $i =count($value);
            for($i=1;$i<$len;$i++){

                 foreach ($counters as $k => $v) {
                    if(array_key_exists($v, $nosum_map)){
                        $newData[$key][0][$v] =max($newData[$key][$i][$v],$newData[$key][0][$v]);

                    }else{
                        $newData[$key][0][$v] +=$newData[$key][$i][$v];
                        
                    }
                    # code...
                }
            }
            $returnDate[] = $newData[$key][0];
           
        }

        return $returnDate;

    }
    public function getResultArray($value,$kpis){
                if(!$value){
                    return array();
                }
                $i=0;
                foreach ($value as $k => $v) {
                    foreach ($v as  $arr) {
                          //时间类型：天/day,天组/dayGroup,小时/hour,小时组/hourgroup,15分钟/quarter
                        if($this->timeDim=="day"){
                            $newFormula[$i]['day']=$arr['DAY'];
                            $newFormula[$i]['location']=$arr['location'];
                            $newFormula[$i]['cellNum'] = $arr['cellNum'];
                        }elseif($this->timeDim=="dayGroup"){
                            $newFormula[$i]['day']=$arr['DAY'];
                            $newFormula[$i]['location']=$arr['location'];
                            $newFormula[$i]['cellNum'] = $arr['cellNum'];
                        }elseif($this->timeDim=="hour"){
                            $newFormula[$i]['day']=$arr['DAY'];
                            $newFormula[$i]['HOUR']=$arr['HOUR'];
                            $newFormula[$i]['location']=$arr['location'];
                            $newFormula[$i]['cellNum'] = $arr['cellNum'];
                        }elseif($this->timeDim=="hourgroup"){
                            $newFormula[$i]['day']=$arr['DAY'];
                            $newFormula[$i]['HOUR']=$arr['HOUR'];
                            $newFormula[$i]['location']=$arr['location'];
                            $newFormula[$i]['cellNum'] = $arr['cellNum'];
                        }elseif($this->timeDim=="quarter"){
                            $newFormula[$i]['day']=$arr['DAY'];
                            $newFormula[$i]['HOUR']=$arr['HOUR'];
                            $newFormula[$i]['MINUTE']=$arr['MINUTE'];
                            $newFormula[$i]['location']=$arr['location'];
                            $newFormula[$i]['cellNum'] = $arr['cellNum'];
                        }
                         //查询维度：city/城市,subnet/子网,subnetGroup/子网组,baseStation/基站,baseStationGroup/基站组,cell/小区,cellGroup/小区组

                        if($this->locationDim=="city"){

                        }elseif($this->locationDim=="subnet"){

                        }elseif($this->locationDim=="subnetGroup"){
                            
                        }elseif($this->locationDim=="baseStation"){
                            $newFormula[$i]['subNet'] = $arr['subNet'];
                            
                        }elseif($this->locationDim=="baseStationGroup"){
                            
                        }elseif($this->locationDim=="cell"){
                            $newFormula[$i]['subNet'] = $arr['subNet'];
                            $newFormula[$i]['site'] = $arr['site'];
                            
                        }elseif($this->locationDim=="cellGroup"){
                            
                        }
                        if(array_key_exists('relation', $arr)){
                            $newFormula[$i]['relation'] = $arr['relation'];

                        }
                         if(array_key_exists('eufdd', $arr)){
                            $newFormula[$i]['eufdd'] = $arr['eufdd'];
                                
                        }
                        $j=0;
                      foreach ($kpis['kpiformula'] as $ks => $vs) {
                        $newFormula[$i]['kpi'.$j]=$this->getCalculationRes($vs['kpiFormula'],$vs['kpiPrecision'],$arr);

                            $j++;
                        }
                        $i++;
                    }
                }
                // print_r($newFormula);exit;
            return $newFormula;
    }

    protected function getCalculationRes($kpiformula, $kpiPrecision, $arr) {
        $kpiformula = strtolower($kpiformula);
        $pattern       = "/[\(\)\+\*-\/]/";
        $columns       = preg_split($pattern, $kpiformula);
        // print_r($columns);
        foreach ($columns as $column) {
            $column      = strtolower(trim($column));
            if (stripos($column, "pm") !== false) {
                preg_match('/^(max|min|avg)\((.*)\)/', $kpiformula, $match);
                if (count($match) == 3) {
                    $columns = $match[1]."\(".$match[2]."\)";
                    // $kpiformula = str_replace($columns, $arr[$column], $kpiformula);
                    $columnstr = "/$columns/";
                    $kpiformula = preg_replace($columnstr, $arr[$column], $kpiformula, 1);
                } else {
                    // $kpiformula = str_replace($column, $arr[$column], $kpiformula);
                    $myColumn = "/$column/";
                    $kpiformula = preg_replace($myColumn, $arr[$column], $kpiformula, 1);
                }
            }
        }//end foreach
        //eval不支持power
        $kpiformula = str_replace('power', 'pow', $kpiformula);
        // print_r($kpiformula);
        try {
            return round(eval("return $kpiformula;"), $kpiPrecision);
            
        } catch (\Exception  $e) {
            return round('0', $kpiPrecision);
            
        }
    }
}
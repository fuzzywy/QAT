<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NbmQueryHandler extends Controller
{
    use KpiQueryHandler;
}

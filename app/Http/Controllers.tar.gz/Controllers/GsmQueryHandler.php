<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GsmQueryHandler extends Controller
{
    use KpiQueryHandler;
}

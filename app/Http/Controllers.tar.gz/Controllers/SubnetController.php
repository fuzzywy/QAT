<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Input;
use App\Http\Controllers\Common\DataBaseConnection;
use App\Eniq;
class SubnetController extends Controller 
{
	public function getSubnet() {

			// print_r(input::all());
		$citys = input::get("citys");
		$dataType = input::get("dataType");
		$dataSource = input::get("dataSource");
		$dbc = new DataBaseConnection();

		$arr = array(array("value"=>"allSelect","label"=>"全选"));

		$subNetWork = $dbc->getSubnetwork($citys,$dataType,$dataSource);

		foreach ($subNetWork as $key=>$value) {
			foreach ($value as $k=>$v) {
				array_push($arr, array("value"=>$key.":".$v,"label"=>$v));
				# code...
			}
		}
		return $arr;
		print_r($arr);
		exit;
		var_dump($arr);exit;
foreach ($citys as $key => $value) {
                    print_r($value);
                    $subnet = Eniq::where("city",$value)->get()->toArray();

                    var_dump($subnet);
                }
		// print_r(Eniq::get()->toArray());
		print_r(input::all());
		sleep(2);
		// print_r(Input::get('citys'));
		// echo 'subnetcontroller';
		//$city = json_encode(Input::get('citys'));
		$arr = array( array( 'value'=>'allSelect', 'label'=>'全选' ),
					  array( 'value'=>'t1', 'label'=>Input::get('citys')[0] ),
					  array( 'value'=>'t2', 'label'=>Input::get('dataSource') ),
					  array( 'value'=>'t3', 'label'=>Input::get('dataType') )
					);
		return $arr;
	}
}

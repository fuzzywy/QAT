<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LteFddQueryHandler extends Controller
{
    use KpiQueryHandler;
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Http\Controllers\LteTddQueryHandler;
use App\Http\Controllers\KpiQueryHandler;
class DataController extends Controller 
{	
	// use KpiQueryHandler;
	public function getQatData(Request $request) {

		$subnets = input::get("subnets");

		foreach ($subnets as $key => $value) {
			if($value&&$value!=="allSelect"){
				$city = explode(":",$value);
				$newsubnets[$city[0]][]=$city[1];
			}
		}
		// print_r($newsubnets);
		// print_r(input::all());
		// exit;
		$test = new LteTddQueryHandler();
		$test->templateQuery($request);
		// print_r($test->createSql());
		// // $test->test();
		// exit;
		// sleep(10);
		// $dataSource = Input::get('dataSource');
		// $dataType = Input::get('dataType');
		// $cancelToken = Input::get('cancelToken');
		// print_r(input::all());
		// exit;

		// // print_r(json_decode($cancelToken));
		// $arr = array(
		// 		array('date'=>'2016-05-03', 'name'=>'1', 'address'=>$cancelToken, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'2', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'3', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'4', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'5', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'6', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'7', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'8', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'9', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'王小虎', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'王小虎', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'王小虎', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'王小虎', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'王小虎', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'王小虎', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'王小虎', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'王小虎', 'address'=>$dataSource, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource ),
		// 		array('date'=>'2016-05-03', 'name'=>'王小虎', 'address'=>$dataType, '这是萨达萨达是啊是大大撒大撒大撒撒打算的阿萨大啊'=>$dataSource)
		// 			);
		// return $arr;
	}
}

<?php
/**
 * Created by PhpStorm.
 * User: yang
 * Date: 2018/11/27
 * Time: 18:02
 */

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Http\Controllers\Common\DataBaseConnection;
use Illuminate\Support\Facades\Redis;
trait KpiQueryHandler
{
    use FormulaHandler;
    //数据库类型：ENIQ
    public $dataSource;
    //数据类型：TDD/FDD/NBIOT/GSM
    public $dataType;
    //模版名
    public $template;
    //时间类型：天/day,天组/dayGroup,小时/hour,小时组/hourgroup,15分钟/quarter
    public $timeDim;
    //查询维度：city/城市,subnet/子网,subnetGroup/子网组,baseStation/基站,baseStationGroup/基站组,cell/小区,cellGroup/小区组
    public $locationDim;
    //城市
    public $cities;
    //子网
    public $subnets;
    //基站
    public $baseStation;
    //小区
    public $cell;
    //日期
    public $dateStart;
    public $dateEnd;
    //小时
    public $hour;

    public $sql;

    public function __construct(){
        $this->sql = new \stdClass();
    }
    // Query template
    public function query(Request $request)
    {   

        $this->dataSource = "ENIQ";
        $this->dataType = "TDD";
        $this->template = "eSRVCC提升";
        $this->timeDim = "day";
        $this->locationDim = "city";
        $subnets = array("changzhou:CZ_Wujin_g1tdd1","nantong:Nantong1_LTE","nantong:Nantong2_LTE","nantong:Nantong4_LTE","nantong:Nantong3_LTE","nantong:Nantong_wlan","nantong2:NT_Nantong_G2tdd1","wuxi:WX_yixing_g2tdd");
        foreach ($subnets as $key => $value) {
            if($value&&$value!=="allSelect"){
                $city = explode(":",$value);
                $newsubnets[$city[0]][]=$city[1];
            }
        }
        // print_r($newsubnets);
        // print_r(array_keys($newsubnets));
        // print_r(array_values($newsubnets));
        $this->cities = array_keys($newsubnets);
        $this->subnets =$newsubnets;
   
        $this->baseStation = "";
        $this->cell = "";
        $this->dateStart =substr($request['date'][0],0,10);
        $this->dateEnd =substr($request['date'][1],0,10);
        $this->hour = "";
        $this->result="";

        // dump($request);
        // Step1
        // getKpis;
        // Step2
        // createSQL
        // // Step A) createslectSql()
        // // Step B) 
        // exit;
    }

    // Create query sql
    public function createSql($city,$subnetwork)
    {   


        if($this->dataSource=="ENIQ"){
            if($this->timeDim=="day"){
                $this->sql->selectSql = "select AGG_TABLE0.DAY,AGG_TABLE0.cellNum,AGG_TABLE0.location,";
                $this->sql->orderbySql = " ORDER BY AGG_TABLE0.DAY";
            }elseif($this->timeDim=="dayGroup"){
            }elseif($this->timeDim=="hour"){
            }elseif($this->timeDim=="hourgroup"){
            }elseif($this->timeDim=="quarter"){
            }
             $dbc = new DataBaseConnection();
            $localDB = $dbc->getDB("mongs");
            $kpis=$this->getKpis($localDB);
            print_r($kpis);
            $counterMap = $this->getCheckCounters($kpis['ids'],$localDB);

            $counters = array_unique(array_keys($counterMap));
            foreach ($counters as $key => $value) {
                $this->sql->selectSql.=$value.",";
            }
            $this->sql->selectSql = trim($this->sql->selectSql,",")." from ";
            $tables  = array_keys(array_count_values($counterMap));

            $tempTableSQL = "";
            $index        = 0;
            foreach ($tables as $table) {
                $countersForQuery = array_keys($counterMap, $table);
                $tableSQL         = $this->createSubQuerySql($countersForQuery,$table,$city);
                // print_r($tableSQL);exit;
                $tableSQL         = $tableSQL."as AGG_TABLE$index ";
                if ($index == 0) {
                    if ($index != (sizeof($tables) - 1)) {
                        $tableSQL = $tableSQL." left join";
                    }
                } else {
                    if ($this->timeDim == "daygroup") {
                        $tableSQL = $tableSQL."on AGG_TABLE0.DAY = AGG_TABLE$index.DAY";
                    } else if ($this->timeDim == "day" || $this->timeDim == 'daygroup') {
                        $tableSQL = $tableSQL."on AGG_TABLE0.day = AGG_TABLE$index.day";
                    } else if ($this->timeDim == "hour") {
                        $tableSQL = $tableSQL."on AGG_TABLE0.day = AGG_TABLE$index.day and AGG_TABLE0.hour = AGG_TABLE$index.hour";
                    } else if ($this->timeDim == "hourgroup") {
                        $tableSQL = $tableSQL."on AGG_TABLE0.day = AGG_TABLE$index.day and AGG_TABLE0.hour = AGG_TABLE$index.hour";
                    } else if ($this->timeDim == "quarter") {
                        $tableSQL = $tableSQL."on AGG_TABLE0.day = AGG_TABLE$index.day and AGG_TABLE0.hour = AGG_TABLE$index.hour and AGG_TABLE0.minute = AGG_TABLE$index.minute";
                    }
                    if ( $this->timeDim == "daygroup" && $this->locationDim == 'cell' ) {
                        $tableSQL = $tableSQL." and AGG_TABLE0.location = AGG_TABLE$index.location";
                    }
                    // echo $locationDim;
                    if ($this->locationDim == "cellGroup" || $this->timeDim == "daygroup"  || $this->locationDim == "erbsGroup") {
                        // echo $locationDim;
                        $tableSQL = $tableSQL;
                    } else {
                        // echo $tableSQL;
                        $tableSQL = $tableSQL." and AGG_TABLE0.location = AGG_TABLE$index.location";
                    }

                    if ($index != (sizeof($tables) - 1)) {
                        $tableSQL = $tableSQL." left join ";
                    }
                }//end if
                $tempTableSQL = $tempTableSQL.$tableSQL;
                $index++;
            }//end foreach

        }
        $sql =    $this->sql->selectSql.$tempTableSQL.$this->sql->orderbySql;
        echo $sql;
        // print_r($this->sql);
        exit;
        $city='nantong2';
    print_r($city);

        // $this->createSubQuerySql();
        // echo $this->createSelectSql();exit;
    //     $dbc = new DataBaseConnection();
    //     $localDB = $dbc->getDB("mongs");
    //     $kpis=$this->getKpis($localDB);
    //     $tables = $this->getCheckCounters($kpis['ids'],$localDB);
    // //     [ids] => 815,3650,825,1090,1095,1092
    // // [names] => VoLTE通话次数(QCI=1),下行RSRP<=-110的比例(%),eSRVCC切换成功率,eSrvcc准备切换尝试次数,eSrvcc执行切换失败次数,eSrvcc准备切换失败次数
    //     print_r($kpis);
    //     $sql = $this->createSelectSql();
        return '';
        // $sql= $this->selectSql.$this->FilterSql.$this->su
    }

    // Create select sql
    public function createSelectSql($city)
    {   
        $conname = trim(preg_replace('/[0-9]+/', '', $city));
    
        $selectSql ="select ";

        if($this->dataSource=="ENIQ"){
            if($this->timeDim=="day"){
                $selectSql.="convert(char(10),date_id) as day,'$conname' as location,";
            }elseif($this->timeDim=="dayGroup"){
                $selectSql.="'ALLDAY' as day,'$conname' as location,";
            }elseif($this->timeDim=="hour"){
                $selectSql .= "convert(char(10),date_id) as day,'$conname' as location,hour_id as hour,";
            }elseif($this->timeDim=="hourgroup"){
        
                if ($this->hour == 'null') {
                    $hour = 'AllHour';
                } else {
                    $hour = ltrim($this->hour, '["');
                    $hour = rtrim($hour, '"]');
                    $hour = implode(',', explode('","', $hour));
                }
                $selectSql .= "convert(char(10),date_id) as day,'$conname' as location,'$hour' as hour,";
            }elseif($this->timeDim=="quarter"){
                $selectSql .= "convert(char,date_id) as day,'$conname' as location,hour_id as hour,min_id as minute,";
            }

        }
        return $selectSql;
    }


    // Create filter sql
    public function createFilterSql($city)
    {   
        //获取单个地市的子网 array()
        $subNetwork = $this->subnets[$city];
        $substr = "";
        foreach ($subNetwork as $key => $value) {
            $substr .="'".$value."',";
        }
        $substr = trim($substr,",");//子网string


        if($this->dataSource=="ENIQ"){

            $subnetwork = $this->getSubnetWork($city);//获取子网
            $aggWhereSql = " where date_id>='".$this->dateStart."' and date_id<='".$this->dateEnd."' and $subnetwork in ($substr)";

            if($this->timeDim=="day"){
            }elseif($this->timeDim=="dayGroup"){
            }elseif($this->timeDim=="hour"){
            }elseif($this->timeDim=="hourgroup"){
            }elseif($this->timeDim=="quarter"){
            }


        }
        return $aggWhereSql;
    }

    // Create group by sql
    public function createGroupBySql()
    {   $aggGroupBy = "";
        if($this->dataSource=="ENIQ"){
            if($this->timeDim=="day"){
                $aggGroupBy = " group by DAY,location";
            }elseif($this->timeDim=="dayGroup"){
                $aggGroupBy = " group by date_id,";
            }elseif($this->timeDim=="hour"){
                $aggGroupBy = " group by date_id,hour_id,";
            }elseif($this->timeDim=="hourgroup"){
                $aggGroupBy = " group by date_id,hour,";
            }elseif($this->timeDim=="quarter"){
                $aggGroupBy = " group by date_id,hour_id,min_id,";
            }


        }
        return $aggGroupBy;
      
    }

    // Create sub query sql for each table
    public function createSubQuerySql($countersForQuery,$table,$city)
    {   
        $aggTypes = $this->loadAggTypes();
        $pattern_nosum = "/(max|min|avg)\((.*)\)/";
        $i=0;
        $selectSQL=$this->createSelectSql($city);
        if($this->dataType=="TDD"){
            $selectSQL.="count(distinct(EutranCellTDD)) as cellNum,";
        }elseif($this->dataType=="FDD"){
            $selectSQL.="count(distinct(EutranCellFDD)) as cellNum,";

        }elseif($this->dataType=="NBIOT"){
            $selectSQL.="count(distinct(NbIotCell)) as cellNum,";

        }
        // if (!$local_flag) {
        //     if ($this->format == 'TDD') {
        //         if ($flag == 'false') {
        //             $selectSQL .= "COUNT(DISTINCT(ERBS)) AS cellNum,";
        //             $resultText = str_replace('cellNum', 'erbsNum', $resultText);
        //         } else {
        //             if ($flag1 == 'false') {
        //                 $selectSQL .= "COUNT(DISTINCT(ERBS)) AS cellNum,";
        //                 $resultText = str_replace('cellNum', 'erbsNum', $resultText);
        //             } else {
        //                 $selectSQL .= "COUNT(DISTINCT(EutranCellTDD)) AS cellNum,";
        //             }
        //         }
        //     } else if ($format == 'FDD') {
        //         $selectSQL .= "COUNT(DISTINCT(ERBS)) AS cellNum,";
        //         $resultText = str_replace('cellNum', 'erbsNum', $resultText);
        //     }else if($format=="NBIOT"){
        //         $selectSQL .= "COUNT(DISTINCT(NbIotCell)) AS cellNum,";
        //         $resultText = str_replace('erbsNum', 'cellNum', $resultText);
        //     }
        // }
        foreach ($countersForQuery as $counter) {
            $counter     = trim($counter);
            $counterName = $counter;

            if (preg_match($pattern_nosum, $counter, $match)) {
                // $counterName = $nosum_map[$counter];
                $minmaxavg = $match[1];
                $pmCounter = $match[2];
                if (stripos($pmCounter, "_") !== false) {
                    $elements = explode("_", $pmCounter);
                    $name     = $elements[0];
                    $index    = $elements[1];
                    $counter  = $this->convertInternalCounter_minmaxavg($minmaxavg, $name, $index);
                    // str_replace(search, replace, subject)
                    $selectSQL .=$counter." as agg".$i++.",";
                    // print_r($selectSQL);exit;
                } else {
                    $counterName = $nosum_map[$counter];
                    $selectSQL .= $counter." as '$counterName',";
                    // print_r($selectSQL);exit;
                }
                
            } else if (stripos($counter, "_") !== false) {
                $elements = explode("_", $counter);
                $name     = $elements[0];
                $index    = $elements[1];
                $counter  = $this->convertInternalCounter($name, $index);
                $selectSQL .=$counter." as '$counterName',";
            } else {
                $aggType = $this->getAggType($aggTypes, $counter);
                $counter = "$aggType($counter)";
                $selectSQL = $selectSQL.$counter." as '$counterName',";
                // print_r($aggType);exit;
            }
            // print_r($selectSQL);exit;
            // $selectSQL = $selectSQL.$counter." as '$counterName',";
        }
        $selectSQL = substr($selectSQL, 0, (strlen($selectSQL) - 1));
        $selectSQL = "($selectSQL from dc.$table ". $this->createFilterSql($city).$this->createGroupBySql().")";
        return $selectSQL;
            return "($selectSQL from dc.$table $whereSQL $groupSQL)";
    }

    // Create subNetwork sql
    public function createSubNetSql()
    {
        $dbc = new DataBaseConnection();
        $localDB = $dbc->getDB("mongs");
        $kpis=$this->getKpis($localDB);
        $tables = $this->getCheckCounters($kpis['ids'],$localDB);
        // foreach($tables as )

    }

    // Export query result
    public function download()
    {
    }

    /**
     * [getKpis description]
     * @DateTime 2018-12-12
     * @param    [type]     $localDB [description]
     * @return   [type]              [description]
     */
    public function getKpis($localDB)
    {

        // $queryKpiset  = "select elementId from template where templateName='".$this->template."' and user = '$parent'";
        $queryKpiset  = "select elementId from template where templateName='".$this->template."'";
        $res          = $localDB->query($queryKpiset);
        $kpis         = $res->fetchColumn();
        $kpisStr      = ','.$kpis.',';
        $queryKpiName = "select kpiName,instr('$kpisStr',CONCAT(',',id,',')) as sort from kpiformula where id in ($kpis) order by sort";
        $res          = $localDB->query($queryKpiName);
        $kpiNames     = "";
        foreach ($res as $row) {
            $kpiNames = $kpiNames.$row['kpiName'].",";
        }

        $kpiNames        = substr($kpiNames, 0, (strlen($kpiNames) - 1));
        $result          = array();
        $result['ids']   = $kpis;
        $result['names'] = $kpiNames;
        return $result;
    }


    protected function getCheckCounters($queryFormula, $localDB) {

        $counters = unserialize(Redis::get("Counters_TDD"));
        $queryFormula  = "select kpiName,kpiFormula,kpiPrecision,instr('$queryFormula,',CONCAT(id,',')) as sort from kpiformula where id in (".$queryFormula.") order by sort";
        $check = [];
        $counterMap = array();
        foreach ($localDB->query($queryFormula) as $row) {
            $kpi = $row['kpiFormula'];
            $pattern       = "/[\(\)\+\*-\/]/";
            $columns       = preg_split($pattern, $kpi);
            $matches       = array();

            $pattern_nosum = "/(max|min|avg)\((.*)\)/";
            foreach ($columns as $column) {
                $column      = trim($column);
                $counterName = $column;
                if (stripos($counterName, "pm") === false) {
                    continue;
                }

                if (stripos($counterName, "_") !== false) {
                    $elements    = explode("_", $counterName);
                    $counterName = $elements[0];
                }
                if (array_key_exists(strtolower($counterName), $counters)) {
                    $table = $counters[strtolower($counterName)];
                } else {
                    continue;
                }

                if($this->dataType=="NBIOT"){
                    $table = trim($table)."_RAW";
                }else{
                    if($this->timeDim=="hour"||$this->timeDim=="quarter"){
                        $table=trim($table)."_RAW";
                    }else{
                        $table   = ($this->timeDim == "day") ? trim($table)."_DAY" : trim($table)."_RAW";
                    }
                }

                if (preg_match($pattern_nosum, $kpi, $matches)) {
                
                    $counterMap[$kpi] = $table;
                    $data = str_replace($matches[0], "agg".count($nosum_map), $kpi);
                    $nosum_map[$kpi]  = $data;
                    break;
                }


                if (!array_key_exists($column, $counterMap)) {
                    $counterMap[$column] = $table;
                }
            }//end foreach
        }
        
        return $counterMap;
        $check = array_unique($check);
        print_r($check);exit;
    }
        /**
     * 转换内部计数器
     *
     * @param string $counterName 计数器名
     * @param string $index       向量值
     *
     * @return mixed
     */
    protected function convertInternalCounter_minmaxavg($minmaxavg, $counterName, $index)
    {
        $SQL = $minmaxavg."(case DCVECTOR_INDEX when $index then $counterName else 0 end)";
        return str_replace("\n", "", $SQL);

    }//end convertInternalCounter()


    /**
     * 获得聚合类型
     *
     * @param array  $aggTypes    聚合类型集合
     * @param string $counterName 计数器名
     *
     * @return string
     */
    protected function getAggType($aggTypes, $counterName)
    {
        // print_r($aggTypes);print_r($counterName);exit;
        if (!array_key_exists($counterName, $aggTypes)) {
            return "sum";
        }

        return trim($aggTypes[$counterName]);

    }//end getAggType()
        protected function convertInternalCounter($counterName, $index)
    {
        $SQL = "sum(case DCVECTOR_INDEX when $index then $counterName else 0 end)";
        return str_replace("\n", "", $SQL);

    }//end convertInternalCounter()

        public function getSubnetWork($oss) {
        $SN = "";
        switch ($oss) {
            case 'wuxiENM':
                $SN = "substring(substring(SN, 0, charindex(',',SN)-1), 12)";
                break;
            case "wuxi1":
                $SN = "substring(SN, 12, charindex(',', SN)-12)";
                break;
          case "wuxi2":
            $SN = "substring(SN, 12, charindex(',', SN)-12)";
            break;
          case "wuxi":
            $SN = "substring(SN, 12, charindex(',', SN)-12)";
            break;
            case "suzhou3":
                $SN = "substring(SN, 12, charindex(',', SN)-12)";
                break;
            case "zhenjiang":
                $SN = "substring(substring(SN, 0, charindex(',',SN)-1), 12)";
            break;
            case "zhenjiang1":
                $SN = "substring(substring(SN, charindex(',', SN)+12), 0, charindex(',', substring(SN, charindex(',', SN)+12))-1)";
                break;
            case "changzhou":
              $SN = "substring(SN, charindex('=', SN)+1, charindex(',', SN)-charindex('=', SN)-1)";
              break;
            case "suzhou":
              $SN = "substring(SN, charindex('=', SN)+1, charindex(',', SN)-charindex('=', SN)-1)";
              break;
            case "nantong2":
              $SN = "substring(SN, charindex('=', SN)+1, charindex(',', SN)-charindex('=', SN)-1)";
              break;
            default:
                $SN = "substring(SN,charindex('=',substring(SN,32,25))+32,charindex(',',substring(SN,32,25))-charindex('=',substring(SN,32,25))-1)";
                break;
        }
        return $SN;
    }

    public function getSN($format, $oss) {
        $SN = "";
        switch ($format) {
            case 'NBIOT':
                switch ($oss) {
                    case 'wuxiENM':
                        $SN = "SN  as site";
                        break;
                    case "suzhou3":
                        $SN = "SN  as site";
                        break;
            case "changzhou":
              $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
              break;
            case "nantong2":
              $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
              break;
                    default:
                        $SN = "substring(substring(SN,charindex (',', substring(SN, 32, 25)) + 32),11,25) as site";
                        break;
                }
                break;
            default:
                switch ($oss) {
                    case 'wuxiENM':
                        $SN = "SN  as site";
                        break;
                    case "zhenjiang1":
                        $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                        break;
                    case "zhenjiang":
                        $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                        break;
                    case "suzhou3":
                        $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                        break;
                    case "wuxi1":
                        $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                        break;
                    case "wuxi":
                        $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                        break;
                case "wuxi2":
                    $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                    break;
                    case "changzhou":
                        $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                        break;
                case "suzhou":
                    $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                    break;
                case "nantong2":
                    $SN = "substring(substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))), charindex('=', substring(substring(SN, charindex (',', SN)+1), charindex(',', substring(SN, charindex (',', SN)+1))+1, char_length(substring(SN, charindex (',', SN)+1))))+1) as site";
                    break;
                    default:
                        $SN = "substring(substring(SN,charindex (',', substring(SN, 32, 25)) + 32),11,25) as site";
                        break;
                }
                break;
        }
        return $SN;
    }
        /**
     * 获得AVG聚合类型的计数器集合
     *
     * @return array
     */
    public function loadAggTypes()
    {
        $aggTypeDefs = file("txt/AggTypeDefine.txt");
        $aggTypes    = array();

        foreach ($aggTypeDefs as $aggTypeDef) {
            $aggType = explode("=", $aggTypeDef);
            $aggTypes[$aggType[0]] = $aggType[1];
        }

        return $aggTypes;

    }//end loadAggTypes()
}
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Eniq;
class LteTddQueryHandler extends Controller
{
    use KpiQueryHandler;

    public function templateQuery(Request $request){

		$this->query($request);

		foreach ($this->subnets as $key => $value) {
			$sql = $this->createSql($key,$value);			
			echo $sql;exit;
		}
    	// $cities = $this->cities;
    	// foreach($this->cities as $key => $value) {
    	// 	$database 
    	// }

    	// print_r($this->cities);
    	
    }

    // public function test(){
    // 	print_r(input::all());
    // 	echo "test";
    // }
    
}
